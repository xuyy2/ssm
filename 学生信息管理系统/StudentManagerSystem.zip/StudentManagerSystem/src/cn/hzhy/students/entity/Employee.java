package cn.hzhy.students.entity;

/**
 * 员工实体类
 * @author Administrator
 *
 */
public class Employee {
	private Integer empId;
	private String empName;
	private String password;

	public Integer getEmpId() {
		return empId;
	}
	
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	

}
